import numpy as np
import pandas as pd
from sklearn import svm
dataset = pd.read_csv('TrainingSet.csv')
y_train = dataset['plant'].values
x_train = dataset[['leaf.length', 'leaf.width', 'flower.length', 'flower.width']].values
svm_model = svm.SVC().fit(x_train, y_train)
test_data = pd.read_csv('TestSet1.csv')
x_test = test_data[['leaf.length', 'leaf.width', 'flower.length', 'flower.width']].values
print(x_test)
y_test = svm_model.predict(x_test)
print(y_test)
predictions = pd.concat([pd.DataFrame(x_test), pd.DataFrame(y_test)], axis=1)
predictions.columns = test_data.columns
predictions.to_csv('result.csv', index=False)
